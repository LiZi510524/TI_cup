/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include <stdio.h>
#include <string.h>
#include "oled.h"
#include "db_amme.h"

extern u16 Huganqibeilv;

void dispaly(float a,float v,float p,float pp);

int main(void)
{
	//�������ʼ��
	board_init();
  NVIC_EnableIRQ(KEY_INT_IRQN);//�����������ŵ�GPIOA�˿��ж�
  InitAmmeter();												 //��ʼ�����ģ��
  OLED_Init();    //��ʼ��OLED
  OLED_Clear();
	
  float a=1.23;
  float v=220.12;
  float p,pp;
  
    while(1) 
    {
      ReadAmmeterData();
      a=PowerData[0].I_Curr;
      v=PowerData[0].Voltage;
      p=PowerData[0].Active_Power;
      pp=PowerData[0].Factor;
      dispaly(a,v,p,pp);
      OLED_Refresh();
      delay_ms(500);
      uart0_send_char(a);
    }
}

void dispaly(float a,float v,float p,float pp)
{
  char Astring[6];
  char Vstring[5];
  char Wstring[5];
  char Pstring[5];
  //char Hstring[5];//ƫ�Ƶ���
  
  
  sprintf(Astring,"%.3f",a);
  sprintf(Vstring,"%.2f",v);
  sprintf(Wstring,"%.1f",a*v);
  sprintf(Pstring,"%.2f",pp);
  //sprintf(Hstring,"%.1f",(float)Huganqibeilv);
  
  OLED_ShowString(0,0,(uint8_t *)"A:",16,1);//8*16 "A:"
  OLED_ShowString(16,0,(uint8_t *)Astring,16,1);//8*16 ��ʾ����
  
  OLED_ShowString(64,0,(uint8_t *)"V:",16,1);//8*16 "V��"
  OLED_ShowString(80,0,(uint8_t *)Vstring,16,1);//8*16 ��ʾ��ѹ
  
  OLED_ShowString(0,20,(uint8_t *)"W:",16,1);//8*16 "W��"
  OLED_ShowString(16,20,(uint8_t *)Wstring,16,1);//8*16 ��ʾ����
  
  OLED_ShowString(64,20,(uint8_t *)"P/S:",16,1);//8*16 "P/S:"
  OLED_ShowString(96,20,(uint8_t *)Pstring,16,1);//8*16 ��ʾ��������
  
  OLED_ShowString(0,40,(uint8_t *)"THD:  %",16,1);//8*16 "THD:  %"
  OLED_ShowNum(32,40,(uint32_t)a,2,16,1);//8*16 ��ʾг��ϵ��
  
  OLED_ShowString(64,40,(uint8_t *)"N:",16,1);//8*16 "A:"
  OLED_ShowNum(80,40,(uint32_t)Huganqibeilv,2,16,1);//8*16 ��ʾƫ�Ƶ���
}

void GROUP1_IRQHandler(void)//Group1���жϷ�����
{
    //��ȡGroup1���жϼĴ���������жϱ�־λ
    switch( DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1) )
    {
        //����Ƿ���KEY��GPIOA�˿��жϣ�ע����INT_IIDX������PIN_18_IIDX 
        case KEY_INT_IIDX:
            //����������±�Ϊ�ߵ�ƽ
            if( DL_GPIO_readPins(KEY_PORT, KEY_PIN_18_PIN) > 0 )
            {
                //����LED����״̬��ת
                Huganqibeilv++;
              if(Huganqibeilv>10)
                Huganqibeilv=1;
            }
        break;
    }
}