/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "board.h"
#include <stdio.h>
#include <string.h>
#include "oled.h"

void dispaly(float a,float v);

int main(void)
{
	//�������ʼ��
	board_init();
  OLED_Init();    //��ʼ��OLED
  OLED_Clear();
	
  
  float a=1.02;
  float v=220.12;

    while(1) 
    {
      dispaly(a,v);
      OLED_Refresh();
      delay_ms(500);
    }
}

void dispaly(float a,float v)
{
  char Astring[5];
  char Vstring[5];
  char Wstring[5];
  char Pstring[5];
  char Hstring[5];//ƫ�Ƶ���
  
  sprintf(Astring,"%.2f",a);
  sprintf(Vstring,"%.2f",v);
  sprintf(Wstring,"%.0f",a*v);
  sprintf(Pstring,"%.2f",a/v);
  sprintf(Hstring,"%.2f",a/v);
  
  OLED_ShowString(0,0,(uint8_t *)"A:",16,1);//8*16 "A:"
  OLED_ShowString(16,0,(uint8_t *)Astring,16,1);//8*16 ��ʾ����
  
  OLED_ShowString(64,0,(uint8_t *)"V:",16,1);//8*16 "V��"
  OLED_ShowString(80,0,(uint8_t *)Vstring,16,1);//8*16 ��ʾ��ѹ
  
  OLED_ShowString(0,20,(uint8_t *)"W:",16,1);//8*16 "W��"
  OLED_ShowString(16,20,(uint8_t *)Wstring,16,1);//8*16 ��ʾ����
  
  OLED_ShowString(64,20,(uint8_t *)"P/S:",16,1);//8*16 "P/S:"
  OLED_ShowString(96,20,(uint8_t *)Pstring,16,1);//8*16 ��ʾ��������
  
  OLED_ShowString(0,40,(uint8_t *)"THD:  %",16,1);//8*16 "THD:  %"
  OLED_ShowNum(32,40,(uint32_t)a,2,16,1);//8*16 ��ʾг��ϵ��
  
  OLED_ShowString(64,40,(uint8_t *)"A:",16,1);//8*16 "A:"
  OLED_ShowString(80,40,(uint8_t *)Hstring,16,1);//8*16 ��ʾƫ�Ƶ���
}